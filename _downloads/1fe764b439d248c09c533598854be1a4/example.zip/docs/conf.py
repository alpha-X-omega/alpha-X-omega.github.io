#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import datetime
import os
import sys

primary_domain='cpp'

extensions = [
    'sphinx.ext.todo',
    'sphinx.ext.mathjax',
    'sphinxcontrib.bibtex'
]
mathjax_path = '{}?{}'.format(
                      'https://cdn.rawgit.com/mathjax/MathJax/2.7.1/MathJax.js',
                      'config=TeX-MML-AM_CHTML')
numfig = True

primary_domain='cpp'

project = 'proto'
author = 'alphaXomega'
copyright = '2013-{0}, {1}'.format(datetime.datetime.now().year, author)

source_suffix = '.rst'

master_doc = 'index'

version = '0.0.0'
release = '0.0.0'

language = None

todo_include_todos = True

exclude_patterns = []
templates_path = ['_templates']
html_static_path = ['_static']

htmlhelp_basename = 'protodoc'

pygments_style = 'sphinx'

html_theme = 'alabaster'
