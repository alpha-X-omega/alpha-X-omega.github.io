Clock
=====

.. namespace:: proto::system

.. class:: Clock

   A monostate class.

.. function:: Clock::Clock()

   Zero overhead constructor.

.. function:: static void Runtime::initialize()

   Initialize the monostate class.

.. function:: void Runtime::setMaxFrameTime(float_t seconds_per_frame)
