"""Generate -line-filter=<string> to suppress third-party issues."""

import argparse
import json
import re
import sys


def parse_line_errors(args):
    """Parse the clang-tidy errors/warnings into a dict."""
    _ = '(\/.*?\/)((?:[^\/]|\\\/)+?):(\d+):(\d+):(\s+warning|\s+error):'
    warning_error_regex = re.compile(_)

    _ = '(\/.*?\/)((?:[^\/]|\\\/)+?):(\d+):(\d+):(\s+note):'
    note_regex = re.compile(_)

    ignore_paths_regex = re.compile('|'.join(args.ignore_paths))

    line_filter = {}
    for line in args.infile:
        _ = line.strip()
        match = warning_error_regex.search(_)
        if match is None:
            continue

        path, filename, line_number = match.group(1, 2, 3)
        line_number = int(line_number)

        # check the subsequent clang-tidy ": note:"
        for _ in range(3):
            note = next(args.infile)

        # either the warning/error gives the file to ignore or the note does
        if ignore_paths_regex.search(note):
            match = note_regex.search(note)
            path, filename, line_number = match.group(1, 2, 3)
            line_number = int(line_number)

        key = path + filename
        filter = line_filter.get(key, {'name': key, 'lines': set()})
        filter['lines'].add(line_number)
        line_filter[key] = filter

    return line_filter


def count_lines(filename):
    """Return the number of new lines in the file."""
    with open(filename) as fis:
        return sum(1 for _ in fis)


def map_lines_to_ranges(line_filter):
    """Negate the clang-tidy errors/warnings line numbers."""
    for key in line_filter:
        filter = line_filter[key]

        total_number_lines = count_lines(key)
        left, right = 1, total_number_lines
        lines = []
        for i in sorted(filter['lines']):
            lines.append([left, max(left, i - 1)])
            left = min(i + 1, right)

        lines.append([left, right])

        filter['lines'] = lines
        line_filter[key] = filter

    return json.dumps(list(line_filter.values()))


def main():
    """Generate line filter for third party source code."""
    _ = main.__doc__
    parser = argparse.ArgumentParser(description=_)
    parser.add_argument('infile', nargs='?', default=sys.stdin,
                        type=argparse.FileType('r'),
                        help='stdout from clang-tidy')
    parser.add_argument('outfile', nargs='?', default=sys.stdout,
                        type=argparse.FileType('w'),
                        help='destination to store generated outputs')
    _ = 'directories to be searched for include directive'
    parser.add_argument('-ignore-paths', nargs='+', default=[], metavar='PATH',
                        help=_)
    args = parser.parse_args()

    filters = parse_line_errors(args)
    json_line_filter = map_lines_to_ranges(filters)

    args.outfile.write(json_line_filter)


if __name__ == "__main__":
    main()
