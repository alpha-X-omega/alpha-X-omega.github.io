"""Implements the include directive of cpp."""

import argparse
import logging
import sys

from pathlib import Path


def find_first_match(idirs, ifile):
    """Return the first file that matches or None."""
    for idir in idirs:
        _ = Path(idir).joinpath(ifile)
        if _.exists():
            return str(_.resolve())

    return None


def process_include(args, infile):
    """Recursively process include directive."""
    for line in infile:
        _ = line.strip()
        if _.startswith('#include'):
            include_file = _.split()[1]
            if include_file.startswith('<') and include_file.endswith('>'):
                # do not search in local file directory
                include_dirs = args.include_dirs
            else:
                # search local file directory first
                _ = [str(Path(infile.name).parent.resolve()),
                     str(Path(infile.name).parent.parent.resolve())]
                include_dirs = args.include_dirs + _

            # remove <> and ""
            include_file = include_file[1:-1]

            match = find_first_match(include_dirs, include_file)
            if match is None:
                _ = 'Cannot find {} while searching in {}.'
                logging.warning(_.format(include_file, include_dirs))
                continue

            logging.info('Including {}'.format(match))
            with open(match, 'r') as match_infile:
                process_include(args, match_infile)
            args.outfile.write('\n')
        else:
            args.outfile.write(line)


def main():
    """Imitate cpp include directive."""
    _ = main.__doc__
    parser = argparse.ArgumentParser(description=_)
    parser.add_argument('infile', nargs='?', default=sys.stdin,
                        type=argparse.FileType('r'),
                        help='input to run preprocessor on')
    parser.add_argument('outfile', nargs='?', default=sys.stdout,
                        type=argparse.FileType('w'),
                        help='destination to store generated outputs')
    _ = 'directories to be searched for include directive'
    parser.add_argument('-I', nargs='+', dest='include_dirs', metavar='',
                        default=[], help=_)
    args = parser.parse_args()
    process_include(args, args.infile)


if __name__ == "__main__":
    main()
