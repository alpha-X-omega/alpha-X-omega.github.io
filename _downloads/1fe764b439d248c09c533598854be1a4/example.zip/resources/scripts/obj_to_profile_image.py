"""Renders each OBJ in a directory from the Euclidean axes."""

import math
import subprocess
import sys

from collections import OrderedDict
from pathlib import Path

import bpy


class CameraViews:
    """A predefined set of camera views."""

    def __init__(self, views=None):
        """Use all views unless particular views are specified."""
        orientations = ['-z', '+z', '+y', '-y', '+x', '-x']
        pi, half_pi = math.pi, math.pi / 2
        eulers = [(0, 0, 0), (pi, 0, 0),
                  (half_pi, 0, 0), (half_pi, 0, pi),
                  (half_pi, 0, -half_pi), (half_pi, 0, half_pi)]
        d = 2.5
        positions = [(0, 0, d), (0, 0, -d),
                     (0, -d, 0), (0, d, 0),
                     (-d, 0, 0), (d, 0, 0)]
        self.views = OrderedDict(zip(orientations, zip(eulers, positions)))

        if views is not None:
            _ = set(orientations)
            views = set(view.lower() for view in views)
            views = _.difference(_.intersection(views))
            for view in views:
                self.views.pop(view)

    def __iter__(self):
        """Return the view's name, rotation, and location."""
        for orientation, (euler, position) in self.views.items():
            yield orientation, euler, position


def render(camera, model, name, output_dir):
    """Save out a render of each view for the given model."""
    views = ['+z', '-z', '+y', '-y', '+x', '-x']
    outputs = []
    for orientation, euler, position in CameraViews(views):
        camera.rotation_euler = euler
        camera.location = position

        _ = '{}/{}_{}'.format(output_dir, name, orientation)
        outputs.append('{}.png'.format(_))
        bpy.context.scene.render.filepath = _
        bpy.ops.render.render(write_still=True)
        # bpy.ops.render.opengl(write_still=True, view_context=False)

    # combine renders into a montage
    argument_list = ['/usr/bin/montage', '-mode concatenate', '-tile 3x2',
                     *outputs, '{}/{}.png'.format(output_dir, name)]
    subprocess.call(' '.join(str(_) for _ in argument_list), shell=True)
    subprocess.call(' '.join(['rm', *outputs]), shell=True)


MAIN_CAMERA = 'Camera'
if MAIN_CAMERA not in bpy.data.objects:
    # create a new camera
    cam_data = bpy.data.cameras.new(MAIN_CAMERA)
    cam_obj = bpy.data.objects.new(MAIN_CAMERA, cam_data)

    # add it to the scene hierarchy
    bpy.context.scene.objects.link(cam_obj)

# select the camera
bpy.context.scene.objects.active = bpy.context.scene.objects[MAIN_CAMERA]
cam = bpy.context.active_object
bpy.context.scene.camera = cam

# enable transformations
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

MAIN_LIGHT = 'Light'
if MAIN_LIGHT not in bpy.data.objects:
    # create new lamp
    lamp_data = bpy.data.lamps.new(name=MAIN_LIGHT, type='HEMI')

    lamp_object = bpy.data.objects.new(name=MAIN_LIGHT, object_data=lamp_data)
    d = 100
    lamp_object.location = (d, ) * 3

    # add it to the scene hierarchy
    bpy.context.scene.objects.link(lamp_object)

    # make it active
    lamp_object.select = True
    bpy.context.scene.objects.active = lamp_object

    light = bpy.context.scene.objects[MAIN_LIGHT]

OUTPUT_DIR = '/home/phi/Documents/proto/resources/tmp/images'
INPUT_DIR = '/home/phi/Documents/proto/resources/tmp'
EXT = 'obj'
for file in Path(INPUT_DIR).glob('*.{}'.format(EXT)):
    # load obj by its filename
    bpy.ops.import_scene.obj(filepath=str(file))

    # import command clears the current selection
    obj = bpy.context.selected_objects[0]

    # translate the object's bounding box origin to (0, 0, 0)
    bpy.ops.object.origin_set(type='GEOMETRY_ORIGIN', center='BOUNDS')

    bpy.ops.object.shade_flat()

    # scale to unit size
    obj.scale = (1.0 / max(obj.dimensions), ) * 3

    # render image from each camera view
    render(cam, obj, file.stem, OUTPUT_DIR)

    # unlink and delete object
    bpy.data.objects.remove(obj, True)

bpy.data.objects.remove(light, True)
bpy.data.objects.remove(cam, True)
