#ifndef PROTO_SYSTEM_LOG_HPP_
#define PROTO_SYSTEM_LOG_HPP_

#include <iostream>

namespace proto::system {

void Log(const char *msg);

template <typename T, typename... Targs>
void Log(const char *msg, T &&value, Targs &&... args) {
  for (; msg != nullptr && *msg != '\0'; ++msg) {
    if (*msg == '{' && *(msg + 1) == '}') {
      std::cerr << value;

      Log(msg + 2, args...);

      return;
    }

    std::cerr << *msg;
  }
}

}  // namespace proto::system

#ifndef NDEBUG

#define REQUIRE(expr, ...)                                                     \
  do {                                                                         \
    if (!(expr)) {                                                             \
      proto::system::Log("{}::{}::{}: pre-condition {}\n", __FILE__, __LINE__, \
                         __func__, #expr);                                     \
      proto::system::Log(__VA_ARGS__);                                         \
      proto::system::Log("\n");                                                \
    }                                                                          \
  } while (false)

#define ENSURE(expr, ...)                                             \
  do {                                                                \
    if (!(expr)) {                                                    \
      proto::system::Log("{}::{}::{}: post-condition {}\n", __FILE__, \
                         __LINE__, __func__, #expr);                  \
      proto::system::Log(__VA_ARGS__);                                \
      proto::system::Log("\n");                                       \
    }                                                                 \
  } while (false)

#define INVARIANT(expr, ...)                                               \
  do {                                                                     \
    if (!(expr)) {                                                         \
      proto::system::Log("{}::{}::{}: invariant {}\n", __FILE__, __LINE__, \
                         __func__, #expr);                                 \
      proto::system::Log(__VA_ARGS__);                                     \
      proto::system::Log("\n");                                            \
    }                                                                      \
  } while (false)

#define LOG(...)                     \
  do {                               \
    proto::system::Log(__VA_ARGS__); \
    proto::system::Log("\n");        \
  } while (false)

#else

#define REQUIRE(...)
#define ENSURE(...)
#define INVARIANT(...)
#define LOG(...)

#endif

#endif  //  PROTO_SYSTEM_LOG_HPP_
