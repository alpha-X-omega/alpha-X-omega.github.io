#ifndef PROTO_SYSTEM_CLOCK_HPP_
#define PROTO_SYSTEM_CLOCK_HPP_

#include <cmath>
#include <cstdint>

#include <chrono>
#include <tuple>

namespace proto::system {

class Clock {
 public:
  Clock(float_t seconds_per_frame, float_t dt);
  Clock() = delete;
  Clock(const Clock &) = delete;
  Clock(Clock &&) = delete;
  Clock &operator=(const Clock &) = delete;
  Clock &operator=(Clock &&) = delete;
  ~Clock();

  float_t dt() const;
  float_t elapsed_time() const;
  float_t remaining_time() const;

  int32_t utc() const;
  int32_t day() const;
  int32_t month() const;
  int32_t year() const;

  void accumulate_remaining_time();
  void advance_time();

 private:
  float_t dt_;
  float_t elapsed_time_;
  float_t max_frame_time_;
  float_t remaining_time_accumulator_;
  decltype(std::chrono::steady_clock::now()) last_measured_time_;
  std::tuple<decltype(std::chrono::steady_clock::now()),
             decltype(std::chrono::system_clock::now())>
      startup_time_;
};

}  // namespace proto::system

#endif  //  PROTO_SYSTEM_CLOCK_HPP_
