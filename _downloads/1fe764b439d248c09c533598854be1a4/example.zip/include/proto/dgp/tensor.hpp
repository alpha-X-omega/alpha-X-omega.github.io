#ifndef PROTO_DGP_TENSOR_HPP_
#define PROTO_DGP_TENSOR_HPP_

#include <cmath>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace proto::dgp {

class Tensor {
 public:
  explicit Tensor(std::vector<size_t> shape);
  Tensor(const float_t *data, std::vector<size_t> shape);
  Tensor(std::vector<float_t> data, std::vector<size_t> shape);
  Tensor(const Tensor &copy);
  Tensor(Tensor &&that) noexcept;
  Tensor &operator=(const Tensor &copy);
  Tensor &operator=(Tensor &&that) noexcept;
  ~Tensor();

  Tensor() = delete;

  float_t *data();
  const float_t *data() const;
  void reshape(std::vector<size_t> shape);
  const std::vector<size_t> &shape() const;
  size_t size() const;

 private:
  std::vector<float_t> data_;
  std::vector<size_t> shape_;
};

Tensor csv_to_tensor(const char *filename);
Tensor csv_to_tensor(const char *filename, char delimiter);

}  // namespace proto::dgp

#endif  //  PROTO_DGP_TENSOR_HPP_
