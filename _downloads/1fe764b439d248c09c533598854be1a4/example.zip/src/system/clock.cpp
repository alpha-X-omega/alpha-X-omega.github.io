#include "proto/system/clock.hpp"

#include <ctime>

#include <algorithm>
#include <iostream>
#include <limits>

#include "proto/system/log.hpp"

using std::chrono::duration;
using std::chrono::duration_cast;
using std::chrono::seconds;
using std::chrono::steady_clock;
using std::chrono::system_clock;
using std::min;

using steady_time_point = decltype(steady_clock::now());
using system_time_point = decltype(system_clock::now());

namespace {

std::tm *get_date(
    const steady_time_point &last_measured_time,
    const std::tuple<steady_time_point, system_time_point> &startup_time) {
  auto diff =
      duration_cast<seconds>(last_measured_time - std::get<0>(startup_time));
  auto t = system_clock::to_time_t(std::get<1>(startup_time) + diff);
  return std::gmtime(&t);
}

}  // namespace

namespace proto::system {

Clock::Clock(float_t seconds_per_frame, float_t dt)
    : dt_(dt),
      elapsed_time_(0),
      max_frame_time_(seconds_per_frame),
      remaining_time_accumulator_(0) {
  std::get<0>(startup_time_) = steady_clock::now();
  std::get<1>(startup_time_) = system_clock::now();
  last_measured_time_ = std::get<0>(startup_time_);

  INVARIANT(elapsed_time_ >= 0, "Elapsed time must be non-negative.");
  INVARIANT(dt_ > 0, "Delta time must be a positive real number.");
  INVARIANT(max_frame_time_ > dt_,
            "Max frame time must be greater than delta time.");
}

Clock::~Clock() = default;

float_t Clock::dt() const { return dt_; }

float_t Clock::elapsed_time() const { return elapsed_time_; }

float_t Clock::remaining_time() const { return remaining_time_accumulator_; }

int32_t Clock::utc() const {
  auto tm = get_date(last_measured_time_, startup_time_);
  return tm->tm_sec + tm->tm_min * 60 + tm->tm_hour * 3600;
}

int32_t Clock::day() const {
  auto tm = get_date(last_measured_time_, startup_time_);
  return tm->tm_mday;
}

int32_t Clock::month() const {
  auto tm = get_date(last_measured_time_, startup_time_);
  return tm->tm_mon + 1;
}

int32_t Clock::year() const {
  auto tm = get_date(last_measured_time_, startup_time_);
  return 1900 + tm->tm_year;
}

void Clock::accumulate_remaining_time() {
  // http://gafferongames.com/game-physics/fix-your-timestep/
  auto new_time = steady_clock::now();
  auto diff = new_time - last_measured_time_;
  auto frame_time = duration<float_t, seconds::period>(diff).count();

  // Avoid spiral of death.
  frame_time = min(frame_time, max_frame_time_);

  last_measured_time_ = new_time;
  remaining_time_accumulator_ += frame_time;

  ENSURE(remaining_time() >= remaining_time() - frame_time,
         "Remaining time must increase non-monotonically.");
}

void Clock::advance_time() {
  elapsed_time_ += dt();
  remaining_time_accumulator_ -= dt();

  ENSURE(elapsed_time() - dt() < elapsed_time(), "Elapsed time must increase.");
  ENSURE(remaining_time() + dt() > remaining_time(),
         "Remaining time must decrease.");
}

}  // namespace proto::system
