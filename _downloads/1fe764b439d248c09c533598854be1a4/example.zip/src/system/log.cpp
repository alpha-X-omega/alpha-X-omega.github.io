#include "proto/system/log.hpp"

namespace proto::system {

void Log(const char *msg) { std::cerr << msg; }

}  // namespace proto::system
