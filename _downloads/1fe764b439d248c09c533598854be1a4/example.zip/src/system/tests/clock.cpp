#include <doctest/doctest.h>

#include <proto/system/clock.hpp>

using doctest::Approx;
using proto::system::Clock;

TEST_CASE("game loop") {
  constexpr auto seconds_per_frame = 0.25f;
  constexpr auto dt = 0.01f;
  Clock clk(seconds_per_frame, dt);

  CHECK(clk.dt() == Approx(0.01).epsilon(0.001));

  auto start_et = clk.elapsed_time();
  auto year = clk.year();
  auto month = clk.month();
  auto day = clk.day();
  auto utc = clk.utc();

  bool loop = true;
  while (loop) {
    // renderer produces time
    clk.accumulate_remaining_time();

    // simulation consumes time
    while (clk.remaining_time() >= clk.dt()) {
      // integrate physics simulation

      // finished simulation
      clk.advance_time();
      loop = false;
    }
  }

  CHECK_LE(start_et, clk.elapsed_time());
  CHECK_EQ(year, clk.year());
  CHECK_EQ(month, clk.month());
  CHECK_EQ(day, clk.day());
  CHECK_LE(utc, clk.utc());

  auto alpha = clk.remaining_time() / clk.dt();
  CHECK_LE(0.0f, alpha);
  CHECK_LE(alpha, 1.0f);
}
