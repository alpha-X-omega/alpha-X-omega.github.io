#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GL/glcorearb.h>

#include <proto/system/log.hpp>

using proto::system::Log;

namespace {

constexpr const char *getStringForSeverity(GLenum severity);
constexpr const char *getStringForSource(GLenum source);
constexpr const char *getStringForType(GLenum type);

void onDebugMessage(GLenum source, GLenum type, GLuint id, GLenum severity,
                    GLsizei length, const GLchar *message,
                    const void *user_param);

}  // namespace

int32_t main(int32_t /*argc*/, const char * /*argv*/ []) {
  auto egl_display = eglGetDisplay(nullptr);

  // initialize EGL for display device
  EGLint major, minor;
  eglInitialize(egl_display, &major, &minor);

  // set rendering API
  eglBindAPI(EGL_OPENGL_API);

  // choose EGL frame buffer configuration that does not use a surface
  EGLint config_attribs[]{EGL_RENDERABLE_TYPE, EGL_OPENGL_BIT, EGL_NONE};
  EGLint num_configs = 0;
  EGLConfig egl_config;
  eglChooseConfig(egl_display, config_attribs, &egl_config, 1, &num_configs);

  // create EGL rendering context
  EGLint context_attribs[]{EGL_CONTEXT_MAJOR_VERSION,
                           4,
                           EGL_CONTEXT_MINOR_VERSION,
                           5,
                           EGL_CONTEXT_OPENGL_PROFILE_MASK,
                           EGL_CONTEXT_OPENGL_CORE_PROFILE_BIT,
#ifdef NVIDIA_FIXED_THIS_DRIVER_BUG
                           EGL_CONTEXT_OPENGL_DEBUG,
                           EGL_TRUE,
                           EGL_CONTEXT_OPENGL_FORWARD_COMPATIBLE,
                           EGL_TRUE,
#else
                           EGL_CONTEXT_FLAGS_KHR,
                           EGL_CONTEXT_OPENGL_DEBUG_BIT_KHR |
                               EGL_CONTEXT_OPENGL_FORWARD_COMPATIBLE_BIT_KHR,
#endif
                           EGL_NONE};
  auto egl_context =
      eglCreateContext(egl_display, egl_config, nullptr, context_attribs);

  // headless rendering i.e. no surface
  eglMakeCurrent(egl_display, nullptr, nullptr, egl_context);

  glEnable(GL_DEBUG_OUTPUT);
  glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
  glDebugMessageCallback(onDebugMessage, nullptr);

  eglDestroyContext(egl_display, egl_context);
  eglTerminate(egl_display);
  eglReleaseThread();

  return 0;
}

namespace {

constexpr const char *getStringForSeverity(GLenum severity) {
  switch (severity) {
    case GL_DEBUG_SEVERITY_HIGH:
      return "High";
    case GL_DEBUG_SEVERITY_LOW:
      return "Low";
    case GL_DEBUG_SEVERITY_MEDIUM:
      return "Medium";
    default:
      return "";
  }
}

constexpr const char *getStringForSource(GLenum source) {
  switch (source) {
    case GL_DEBUG_SOURCE_API:
      return "API";
    case GL_DEBUG_SOURCE_APPLICATION:
      return "Application";
    case GL_DEBUG_SOURCE_OTHER:
      return "Other";
    case GL_DEBUG_SOURCE_SHADER_COMPILER:
      return "Shader Compiler";
    case GL_DEBUG_SOURCE_THIRD_PARTY:
      return "Third Party";
    case GL_DEBUG_SOURCE_WINDOW_SYSTEM:
      return "Window System";
    default:
      return "";
  }
}

constexpr const char *getStringForType(GLenum type) {
  switch (type) {
    case GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR:
      return "Deprecated Behaviour";
    case GL_DEBUG_TYPE_ERROR:
      return "Error";
    case GL_DEBUG_TYPE_PERFORMANCE:
      return "Performance Issue";
    case GL_DEBUG_TYPE_PORTABILITY:
      return "Portability Issue";
    case GL_DEBUG_TYPE_OTHER:
      return "Other";
    case GL_DEBUG_TYPE_UNDEFINED_BEHAVIOR:
      return "Undefined Behaviour";
    default:
      return "";
  }
}

void onDebugMessage(GLenum source, GLenum type, GLuint id, GLenum severity,
                    GLsizei length, const GLchar *message,
                    const void * /*user_param*/) {
  constexpr const char *error_msg_fmt =
      "Type: {}; Source: {}; ID: {}; Severity: {}\n      Message({}): {}\n";
  Log(error_msg_fmt, getStringForType(type), getStringForSource(source), id,
      getStringForSeverity(severity), length, message);
}

}  // namespace
