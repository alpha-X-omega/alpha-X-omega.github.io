#include "proto/dgp/tensor.hpp"

#include <algorithm>
#include <fstream>
#include <functional>
#include <memory>
#include <numeric>
#include <sstream>
#include <utility>

#include "proto/system/log.hpp"

using std::accumulate;
using std::move;
using std::vector;

namespace proto::dgp {

Tensor::Tensor(vector<size_t> shape) : shape_(move(shape)) {
  data_.resize(size(), 0);
}

Tensor::Tensor(const float_t *data, vector<size_t> shape)
    : shape_(move(shape)) {
  data_.assign(data, data + size());
}

Tensor::Tensor(vector<float_t> data, vector<size_t> shape) {
  data_ = move(data);

  if (shape.empty()) {
    shape_.push_back(data_.size());
  } else {
    shape_ = move(shape);
  }

  ENSURE(size() == data_.size(), "Shape must match size of data.");
}

Tensor::Tensor(const Tensor &) = default;

Tensor::Tensor(Tensor &&that) noexcept
    : data_(move(that.data_)), shape_(move(that.shape_)) {}

Tensor &Tensor::operator=(const Tensor &copy) {
  REQUIRE(size() == copy.size(),
          "New total size ({}) does not match previous total size ({}).",
          copy.size(), size());

  data_ = copy.data_;
  shape_ = copy.shape_;

  return *this;
}

Tensor &Tensor::operator=(Tensor &&that) noexcept {
  REQUIRE(size() == that.size(),
          "New total size ({}) does not match previous total size ({}).",
          that.size(), size());

  data_ = move(that.data_);
  shape_ = move(that.shape_);

  return *this;
}

Tensor::~Tensor() = default;

float_t *Tensor::data() { return data_.data(); }

const float_t *Tensor::data() const { return data_.data(); }

void Tensor::reshape(vector<size_t> shape) {
  REQUIRE((shape_.empty() && shape.empty()) ||
              size() == accumulate(shape.begin(), shape.end(), 1u,
                                   std::multiplies<>()),
          "New total size ({}) does not match previous total size ({}).",
          accumulate(shape.begin(), shape.end(), 1u, std::multiplies<>()),
          size());

  shape_ = move(shape);
}

const vector<size_t> &Tensor::shape() const { return shape_; }

size_t Tensor::size() const {
  if (shape_.empty()) {
    return 0;
  }

  return accumulate(shape_.begin(), shape_.end(), 1u, std::multiplies<>());
}

Tensor csv_to_tensor(const char *filename) {
  return csv_to_tensor(filename, ',');
}

Tensor csv_to_tensor(const char *filename, char delimiter) {
  std::ifstream file(filename, std::ios::binary);

  std::vector<float_t> array;

  std::string line;
  while (std::getline(file, line)) {
    std::istringstream ss(line);

    std::string token;
    while (std::getline(ss, token, delimiter)) {
      array.push_back(std::stof(token));
    }
  }

  return Tensor(array, {});
}

}  // namespace proto::dgp
