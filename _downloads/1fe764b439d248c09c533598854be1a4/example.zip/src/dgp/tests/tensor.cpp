#include <doctest/doctest.h>

#include <proto/dgp/tensor.hpp>

using doctest::Approx;
using proto::dgp::Tensor;
using proto::dgp::csv_to_tensor;

TEST_CASE("tensor construction") {
  constexpr auto kPermyriad = 0.001;
  float_t s[]{0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 0.0};
  auto len_s = sizeof(s) / sizeof(s[0]);

  SUBCASE("tensor constructor allocates an empty array") {
    std::vector<size_t> empty;
    Tensor t(empty);

    CHECK_EQ(t.size(), empty.size());
  }

  SUBCASE("tensor constructor allocates an uninitialized linear array") {
    Tensor t({len_s});

    CHECK_EQ(t.size(), len_s);
  }

  SUBCASE(
      "tensor move constructor with unspecified shape copies into a linear "
      "array") {
    Tensor t_linear({0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 2.0, 0.0}, {});
    CHECK_EQ(t_linear.size(), len_s);

    for (auto i = 0u; i < len_s; ++i) {
      auto v = t_linear.data()[i];
      CHECK(v == Approx(static_cast<double>(s[i])).epsilon(kPermyriad));
    }
  }

  SUBCASE("tensor constructor copies data with equal size") {
    Tensor t_linear(s, {len_s});
    t_linear.reshape({3, 3});

    Tensor t(s, t_linear.shape());
    CHECK(std::equal(t.shape().begin(), t.shape().end(),
                     t_linear.shape().begin(), t_linear.shape().end()));
  }

  SUBCASE("tensor copy constructor does a deep copy") {
    Tensor t(s, {len_s});
    Tensor t_copy(t);

    CHECK(std::equal(t.shape().begin(), t.shape().end(), t_copy.shape().begin(),
                     t_copy.shape().end()));
    CHECK_EQ(0, std::memcmp(t_copy.data(), s, sizeof(s)));
  }

  SUBCASE("tensor move constructor does a deep copy") {
    Tensor t_move(Tensor(s, {len_s}));
    CHECK_EQ(0, std::memcmp(t_move.data(), s, sizeof(s)));
    CHECK_EQ(t_move.size(), len_s);
    CHECK_EQ(t_move.shape().size(), 1u);
    CHECK_EQ(t_move.shape()[0], len_s);
  }

  SUBCASE("edge copy assignment does a deep copy") {
    Tensor t_ca({len_s});
    Tensor t(s, {3u, 3u});
    t_ca = t;

    CHECK_EQ(0, std::memcmp(t_ca.data(), s, sizeof(s)));
    CHECK_EQ(t_ca.size(), len_s);
    CHECK_EQ(t_ca.shape().size(), 2u);
    CHECK_EQ(t_ca.shape()[0], t_ca.shape()[1]);
  }

  SUBCASE("edge move assignment does a deep copy") {
    Tensor t_ma({len_s});
    t_ma = Tensor(s, {3u, 3u});

    CHECK_EQ(0, std::memcmp(t_ma.data(), s, sizeof(s)));
    CHECK_EQ(t_ma.size(), len_s);
    CHECK_EQ(t_ma.shape().size(), 2u);
    CHECK_EQ(t_ma.shape()[0], t_ma.shape()[1]);
  }
}

TEST_CASE("CSV to Tensor") {
  auto T = proto::dgp::csv_to_tensor("data/point-correspondences.txt");
  float_t values[]{0.0, 0.0, 0.0, 1.0,  0.0, 0.0, 0.0, 2.0, 0.0,
                   0.0, 0.0, 0.0, -1.0, 0.0, 0.0, 0.0, 2.0, 0.0};
  T.reshape({2, 9});
  CHECK_EQ(0, memcmp(T.data(), values, sizeof(values)));
  CHECK_EQ(T.size(), 18);
}
